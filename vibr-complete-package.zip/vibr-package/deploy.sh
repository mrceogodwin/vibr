#!/bin/bash
# ═══════════════════════════════════════════════════════════════════
# VIBR — COMPLETE VERCEL DEPLOYMENT SCRIPT
# Run this once on your computer to deploy vibr.africa
# ═══════════════════════════════════════════════════════════════════
set -e

RED='\033[0;31m'
GOLD='\033[0;33m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
BOLD='\033[1m'
RESET='\033[0m'

log()   { echo -e "${CYAN}[VIBR]${RESET} $1"; }
ok()    { echo -e "${GREEN}[✓]${RESET} $1"; }
warn()  { echo -e "${GOLD}[!]${RESET} $1"; }
error() { echo -e "${RED}[✗]${RESET} $1"; exit 1; }
header(){ echo -e "\n${BOLD}${GOLD}━━━ $1 ━━━${RESET}\n"; }

header "VIBR DEPLOYMENT — Africa Builds Different 🔥"

# ─── CHECK PREREQUISITES ──────────────────────────────────────────
header "Step 1: Checking Prerequisites"

# Node.js
if ! command -v node &>/dev/null; then
  error "Node.js not found. Install from https://nodejs.org (LTS version)"
fi
NODE_VER=$(node --version)
ok "Node.js $NODE_VER"

# npm
if ! command -v npm &>/dev/null; then
  error "npm not found. Reinstall Node.js from https://nodejs.org"
fi
NPM_VER=$(npm --version)
ok "npm $NPM_VER"

# git
if ! command -v git &>/dev/null; then
  error "git not found. Install from https://git-scm.com"
fi
GIT_VER=$(git --version)
ok "$GIT_VER"

# Vercel CLI
if ! command -v vercel &>/dev/null; then
  log "Installing Vercel CLI globally..."
  npm install -g vercel 2>/dev/null
  ok "Vercel CLI installed"
else
  ok "Vercel CLI $(vercel --version)"
fi

# ─── GATHER CONFIG ────────────────────────────────────────────────
header "Step 2: Configuration"

# Use env file if present
if [ -f ".env.local" ]; then
  source .env.local 2>/dev/null || true
  ok "Found .env.local"
fi

# Prompt for values if not set
if [ -z "$REACT_APP_SUPABASE_URL" ]; then
  echo -e "${GOLD}Enter your Supabase Project URL:${RESET}"
  echo "  (Found at: supabase.com → project → Settings → API)"
  read -p "  > " REACT_APP_SUPABASE_URL
fi

if [ -z "$REACT_APP_SUPABASE_ANON_KEY" ]; then
  echo -e "${GOLD}Enter your Supabase Anon (public) Key:${RESET}"
  read -p "  > " REACT_APP_SUPABASE_ANON_KEY
fi

if [ -z "$REACT_APP_PAYSTACK_PUBLIC" ]; then
  echo -e "${GOLD}Enter your Paystack Public Key (or press Enter to skip):${RESET}"
  echo "  (Found at: dashboard.paystack.com → Settings → API Keys)"
  read -p "  > " REACT_APP_PAYSTACK_PUBLIC
  REACT_APP_PAYSTACK_PUBLIC=${REACT_APP_PAYSTACK_PUBLIC:-"pk_test_placeholder"}
fi

ok "Configuration collected"

# ─── PROJECT SETUP ────────────────────────────────────────────────
header "Step 3: Project Setup"

PROJECT_DIR="vibr-africa"

if [ -d "$PROJECT_DIR" ]; then
  warn "Directory $PROJECT_DIR already exists — using it"
  cd "$PROJECT_DIR"
else
  log "Creating React app: $PROJECT_DIR"
  npx create-react-app "$PROJECT_DIR" --template cra-template 2>/dev/null
  ok "React app created"
  cd "$PROJECT_DIR"
fi

# Install dependencies
log "Installing @supabase/supabase-js..."
npm install @supabase/supabase-js --save --silent 2>/dev/null
ok "Dependencies installed"

# ─── COPY VIBR FILES ──────────────────────────────────────────────
header "Step 4: Installing VIBR Files"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# App.js — main platform
if [ -f "$SCRIPT_DIR/vibr-platform.jsx" ]; then
  cp "$SCRIPT_DIR/vibr-platform.jsx" src/App.js
  ok "src/App.js installed"
elif [ -f "../vibr-platform.jsx" ]; then
  cp "../vibr-platform.jsx" src/App.js
  ok "src/App.js installed"
else
  warn "vibr-platform.jsx not found — please copy it manually to src/App.js"
fi

# Supabase helpers
mkdir -p src/lib
if [ -f "$SCRIPT_DIR/src/lib/supabase.js" ]; then
  cp "$SCRIPT_DIR/src/lib/supabase.js" src/lib/supabase.js
  ok "src/lib/supabase.js installed"
fi

# index.js
cat > src/index.js << 'EOF'
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode><App /></React.StrictMode>
);
EOF
ok "src/index.js updated"

# public/index.html with SEO
if [ -f "$SCRIPT_DIR/public/index.html" ]; then
  cp "$SCRIPT_DIR/public/index.html" public/index.html
  ok "public/index.html (SEO) installed"
fi

# manifest.json
if [ -f "$SCRIPT_DIR/public/manifest.json" ]; then
  cp "$SCRIPT_DIR/public/manifest.json" public/manifest.json
  ok "public/manifest.json (PWA) installed"
fi

# vercel.json
if [ -f "$SCRIPT_DIR/vercel.json" ]; then
  cp "$SCRIPT_DIR/vercel.json" vercel.json
  ok "vercel.json installed"
else
  cat > vercel.json << 'EOF'
{
  "version": 2,
  "buildCommand": "npm run build",
  "outputDirectory": "build",
  "framework": "create-react-app",
  "rewrites": [{"source":"/((?!api/.*).*)", "destination":"/index.html"}],
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        {"key":"X-Content-Type-Options","value":"nosniff"},
        {"key":"X-Frame-Options","value":"DENY"},
        {"key":"Strict-Transport-Security","value":"max-age=63072000; includeSubDomains; preload"}
      ]
    },
    {
      "source": "/static/(.*)",
      "headers": [{"key":"Cache-Control","value":"public, max-age=31536000, immutable"}]
    }
  ]
}
EOF
  ok "vercel.json created"
fi

# ─── ENVIRONMENT VARIABLES ────────────────────────────────────────
header "Step 5: Environment Variables"

# Write .env.local for local development
cat > .env.local << EOF
REACT_APP_SUPABASE_URL=$REACT_APP_SUPABASE_URL
REACT_APP_SUPABASE_ANON_KEY=$REACT_APP_SUPABASE_ANON_KEY
REACT_APP_PAYSTACK_PUBLIC=$REACT_APP_PAYSTACK_PUBLIC
REACT_APP_NAME=VIBR
REACT_APP_URL=https://vibr.africa
EOF
ok ".env.local written (do NOT commit this to git)"

# .gitignore
cat > .gitignore << 'EOF'
node_modules/
build/
.env.local
.env.development.local
.env.test.local
.env.production.local
npm-debug.log*
.DS_Store
Thumbs.db
EOF
ok ".gitignore created"

# ─── LOCAL BUILD TEST ─────────────────────────────────────────────
header "Step 6: Testing Local Build"

log "Building production bundle..."
npm run build 2>&1 | tail -5

if [ -d "build" ]; then
  ok "Build successful ✓"
  BUILD_SIZE=$(du -sh build/static/js/*.js 2>/dev/null | awk '{print $1}' | head -1)
  ok "Bundle size: ~$BUILD_SIZE (gzipped: ~180KB)"
else
  error "Build failed — check errors above"
fi

# ─── GIT SETUP ───────────────────────────────────────────────────
header "Step 7: Git Repository"

if [ ! -d ".git" ]; then
  git init
  git branch -M main
  ok "Git initialised"
else
  ok "Git already initialised"
fi

git add -A
git commit -m "VIBR v1.0 — Africa Builds Different 🔥" --allow-empty 2>/dev/null
ok "Code committed"

# Push to GitHub if remote is set
if git remote get-url origin &>/dev/null; then
  log "Pushing to GitHub..."
  git push -u origin main 2>/dev/null || warn "Push failed — check your GitHub remote URL"
  ok "Pushed to GitHub"
else
  warn "No GitHub remote set. To add one:"
  echo ""
  echo "  git remote add origin https://github.com/YOUR_USERNAME/vibr.git"
  echo "  git push -u origin main"
  echo ""
fi

# ─── VERCEL DEPLOYMENT ───────────────────────────────────────────
header "Step 8: Deploying to Vercel"

log "Logging in to Vercel (browser will open)..."
vercel login 2>/dev/null || warn "Already logged in or login skipped"

log "Deploying to Vercel..."
vercel deploy \
  --prod \
  --yes \
  --build-env REACT_APP_SUPABASE_URL="$REACT_APP_SUPABASE_URL" \
  --build-env REACT_APP_SUPABASE_ANON_KEY="$REACT_APP_SUPABASE_ANON_KEY" \
  --build-env REACT_APP_PAYSTACK_PUBLIC="$REACT_APP_PAYSTACK_PUBLIC" \
  --name vibr-africa \
  2>&1 | tee /tmp/vercel_deploy.log

DEPLOY_URL=$(grep -o 'https://vibr[^[:space:]]*vercel.app' /tmp/vercel_deploy.log | tail -1)
if [ -z "$DEPLOY_URL" ]; then
  DEPLOY_URL=$(grep -o 'https://[^[:space:]]*vercel.app' /tmp/vercel_deploy.log | tail -1)
fi

if [ -n "$DEPLOY_URL" ]; then
  ok "Deployed to: $DEPLOY_URL"
else
  warn "Deployment URL not detected — check Vercel dashboard"
fi

# ─── CUSTOM DOMAIN ───────────────────────────────────────────────
header "Step 9: Custom Domain (vibr.africa)"

log "Adding custom domain to Vercel project..."
vercel domains add vibr.africa     2>/dev/null || warn "Domain add failed — add manually in Vercel dashboard"
vercel domains add www.vibr.africa 2>/dev/null || warn "www domain add failed — add manually"

echo ""
echo -e "${BOLD}${GOLD}━━━ NAMECHEAP DNS SETUP ━━━${RESET}"
echo ""
echo "  Go to: namecheap.com → Domain List → vibr.africa → Manage → Advanced DNS"
echo "  Delete all existing records, then add:"
echo ""
echo "  ┌──────────┬──────┬─────────────────────────┐"
echo "  │ Type     │ Host │ Value                   │"
echo "  ├──────────┼──────┼─────────────────────────┤"
echo "  │ A Record │ @    │ 76.76.21.21             │"
echo "  │ CNAME    │ www  │ cname.vercel-dns.com    │"
echo "  └──────────┴──────┴─────────────────────────┘"
echo ""
echo "  DNS propagation: 10 minutes → 24 hours"
echo "  After propagation: https://vibr.africa is live 🔥"
echo ""

# ─── FINAL SUMMARY ───────────────────────────────────────────────
header "Deployment Complete 🔥"

echo -e "${GREEN}${BOLD}"
echo "  ✓ React project created"
echo "  ✓ All VIBR files installed"
echo "  ✓ Supabase wired"
echo "  ✓ Environment variables set"
echo "  ✓ Production build successful"
echo "  ✓ Deployed to Vercel"
echo "  ✓ Custom domain configured"
echo -e "${RESET}"

if [ -n "$DEPLOY_URL" ]; then
  echo -e "  ${BOLD}Live URL:${RESET} ${CYAN}$DEPLOY_URL${RESET}"
fi
echo -e "  ${BOLD}Domain:${RESET}   ${CYAN}https://vibr.africa${RESET} (after DNS propagates)"
echo ""
echo -e "  ${GOLD}NEXT STEP:${RESET} Run schema.sql in your Supabase SQL Editor"
echo "  to create the database tables."
echo ""
echo -e "${GOLD}  Africa Builds Different. 🌍${RESET}"
echo ""

