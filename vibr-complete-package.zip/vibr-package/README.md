# VIBR — Africa Builds Different 🔥

> The platform where African builders get seen by investors and companies.  
> Drop projects. Find co-founders. Get hired. Get funded.

**vibr.africa** · React 18 · Supabase · Paystack · Vercel

---

## What's in This Package

```
vibr/
├── src/
│   ├── App.js                  ← Full platform (use vibr-platform-fixed.jsx)
│   └── lib/
│       └── supabase.js         ← Supabase client + all DB helpers
├── public/
│   ├── index.html              ← SEO + PWA meta tags
│   └── manifest.json           ← PWA manifest (VIBR as installable app)
├── vibr-preview.html           ← 🔥 OPEN THIS IN BROWSER — works immediately, no setup
├── vibr-platform-fixed.jsx     ← Production file (real Supabase, no errors)
├── vibr-preview-fixed.jsx      ← Preview file (mock data, no backend needed)
├── schema.sql                  ← Full Supabase database schema (run once)
├── deploy.sh                   ← One-command Vercel deployment script
├── vercel.json                 ← Vercel config (routing, headers, CDN regions)
├── package.json                ← Dependencies
├── .env.example                ← Environment variable template
└── README.md                   ← This file
```

---

## Quickest Start — Open the Preview

**No setup needed. Just open:**
```
vibr-preview.html
```
Double-click it in your file manager. Opens in any browser. Full platform, demo data, zero backend.

---

## Run Locally (5 minutes)

```bash
# 1. Create React app
npx create-react-app vibr
cd vibr

# 2. Install Supabase
npm install @supabase/supabase-js

# 3. Copy your VIBR files
cp vibr-platform-fixed.jsx src/App.js
cp supabase.js src/lib/supabase.js

# 4. Set environment variables
cp .env.example .env.local
# Edit .env.local with your Supabase and Paystack keys

# 5. Set up database (one time)
# Go to supabase.com → SQL Editor → paste schema.sql → Run

# 6. Start
npm start
# Opens at http://localhost:3000
```

---

## Environment Variables

Create `.env.local` from `.env.example`:

```env
REACT_APP_SUPABASE_URL=https://yklvriwmsfkfaxkqaxvu.supabase.co
REACT_APP_SUPABASE_ANON_KEY=your_anon_key_here
REACT_APP_PAYSTACK_PUBLIC=pk_live_xxxxxxxxxxxxxxxxxxxx
REACT_APP_CLOUDINARY_CLOUD=your_cloud_name
REACT_APP_CLOUDINARY_UPLOAD_PRESET=vibr_unsigned
```

⚠️ **Never commit `.env.local` to git. It's in .gitignore.**

---

## Database Setup

Run `schema.sql` **once** in your Supabase SQL Editor:

1. Go to [supabase.com](https://supabase.com) → your project
2. Click **SQL Editor** → **New query**
3. Paste entire `schema.sql` contents
4. Click **Run**

Creates:
- **29 tables** — profiles, posts, votes, comments, messages, conversations, notifications, collabs, bounties, challenges, squads, spaces, chapters, hackathons, subscriptions, follows, and more
- **75 RLS policies** — every table secured per user role
- **5 triggers** — auto-create profile on signup, vote counts, rank updates
- **14 indexes** — optimised for common query patterns
- **Seed data** — 8 country chapters, 6 Spaces channels, 2 hackathons

---

## Supabase Storage

After schema.sql, create storage buckets:

```sql
-- Run in Supabase SQL Editor
INSERT INTO storage.buckets (id, name, public) VALUES ('avatars', 'avatars', true);

CREATE POLICY "Avatar upload" ON storage.objects
  FOR INSERT WITH CHECK (
    bucket_id = 'avatars' AND
    auth.uid()::text = (storage.foldername(name))[1]
  );

CREATE POLICY "Avatar read" ON storage.objects
  FOR SELECT USING (bucket_id = 'avatars');
```

---

## Paystack Integration

1. Create account at [paystack.com](https://paystack.com)
2. Complete business KYC (2–5 business days)
3. Use test keys while waiting: `pk_test_...`
4. Add to `.env.local` as `REACT_APP_PAYSTACK_PUBLIC`
5. Add to `public/index.html` before `</body>`:

```html
<script src="https://js.paystack.co/v1/inline.js"></script>
```

**VIBR Premium Tiers:**
| Plan | Price | Features |
|---|---|---|
| Vibe Pro | ₦3,500/month | Verified badge, collab priority, unlimited drops |
| Vibe Lord | ₦8,000/month | Everything + investor access + analytics |

---

## Deploy to Vercel

### Option A — Automated (recommended)
```bash
chmod +x deploy.sh
./deploy.sh
```
Handles everything: build, GitHub push, Vercel deploy, domain config.

### Option B — Manual

**Step 1 — Push to GitHub**
```bash
git init
git add .
git commit -m "VIBR v1 — Africa Builds Different 🔥"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/vibr.git
git push -u origin main
```

**Step 2 — Import to Vercel**
1. Go to [vercel.com](https://vercel.com) → Sign up with GitHub
2. **Add New Project** → Import your `vibr` repo
3. Framework: **Create React App** (auto-detected)
4. Add environment variables (Settings → Environment Variables):
   - `REACT_APP_SUPABASE_URL`
   - `REACT_APP_SUPABASE_ANON_KEY`
   - `REACT_APP_PAYSTACK_PUBLIC`
5. Click **Deploy** — live in 60 seconds ✅

**Step 3 — Connect vibr.africa**

In **Namecheap → Advanced DNS:**

| Type | Host | Value |
|---|---|---|
| A Record | @ | 76.76.21.21 |
| CNAME | www | cname.vercel-dns.com |

In **Vercel → Settings → Domains:**
- Add `vibr.africa`
- Add `www.vibr.africa`

DNS propagates in 10 min → 24 hours.

**Step 4 — Future deploys (automatic)**
```bash
git add .
git commit -m "your update"
git push
# Auto-deploys to vibr.africa. Zero manual steps.
```

---

## Platform Features

### User Roles
| Role | Access |
|---|---|
| Builder | Full platform — feed, drops, collabs, bounties, squads, spaces |
| Investor | Deal flow dashboard + browse builders + post bounties |
| Company | Talent pipeline + bounties + challenge hosting |
| Admin | Full control panel (direct URL only — never linked) |

### Core Features (31 Routes)
| Feature | Description |
|---|---|
| **Feed** | Live project drops, upvoting, trending algorithm, infinite scroll |
| **Drop** | Post projects with tags, collab flags, bounty indicators |
| **Collab Board** | Find co-founders and collaborators by role and stack |
| **Bounties** | Paid work from companies, apply directly, Paystack payout |
| **Challenges** | Sponsored multi-track challenges with demo room review |
| **Leaderboard** | Real vibe points from drops, votes, completions |
| **SQVAD** | Private builder crews — invite members via DM, squad chat |
| **Spaces** | 6 topic channels (React Africa, AI & ML, Fintech Nigeria…) |
| **Community Chapters** | 8 country discussion rooms (NG, GH, KE, SA, SN, ZW, CM, UG) |
| **Hackathons** | Live event rooms with VIBR Bot, registered-only |
| **Messaging (DM)** | Private 1-on-1 real-time chat |
| **Search** | Full-text search across posts, builders, bounties |
| **Notifications** | Real-time, per-user, filterable |
| **Premium** | 3 tiers via Paystack — Vibe Pro + Vibe Lord |
| **Settings** | Profile, notifications, privacy, security, WhatsApp |

### 5 Chat Systems
1. **DMs** — Private 1-on-1 messages (real-time via Supabase)
2. **Squad Chat** — Private group chat per SQVAD (real-time)
3. **Spaces** — Open topic channels
4. **Chapter Chat** — Country hub discussions
5. **Hackathon Rooms** — Registered-only event chat

### Dashboards
- **Investor** — Deal flow, talent pipeline, post bounties, portfolio, full platform browse
- **Company** — Overview, post bounties, talent search, challenge submissions, hackathon sponsorship
- **Admin** — Platform stats, member management, content moderation, revenue, broadcast messages

---

## Bugs Fixed in This Release

| # | Bug | Component | Fix |
|---|---|---|---|
| 1 | `openChat` & `setOpenChat` undefined | `SqvadPage` | Added missing `useState` declaration |
| 2 | `profileForm` undefined in save handler | `SettingsPage` | Added missing `useState` declaration |
| 3 | `a[b.id]` — `a` not defined | Bounties Apply button | Changed to correct variable `applied[b.id]` |

Both `vibr-platform-fixed.jsx` and `vibr-preview-fixed.jsx` have all 3 bugs resolved.  
**Build result: ✅ Zero errors. Warnings only (unused vars — harmless).**

---

## What Comes Next

| Priority | Feature | Dependency |
|---|---|---|
| 1 | Paystack live payments | Business account approval (2–5 days) |
| 2 | Avatar uploads live | Supabase Storage setup (5 min) |
| 3 | Email notifications | Resend.com free account |
| 4 | Investor KYC verification | Persona.com or Sumsub API key |
| 5 | Admin subdomain | Deploy admin.vibr.africa separately |
| 6 | WhatsApp notifications | WhatsApp Business API |
| 7 | Mobile app | React Native — reuses Supabase layer |

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 18, single-file architecture |
| Styling | Inline CSS, CSS variables, Bebas Neue + Space Mono + DM Sans |
| Database | Supabase (PostgreSQL + Row Level Security) |
| Auth | Supabase Auth (JWT, auto-refresh, session persistence) |
| Real-time | Supabase Realtime (WebSocket channels) |
| Storage | Supabase Storage (avatars, media) |
| Payments | Paystack (NGN, GHS, KES, ZAR — cards, bank, USSD) |
| Hosting | Vercel (Edge CDN, 3 regions: US, EU, Asia) |
| Domain | Namecheap → vibr.africa |

---

## Brand

| Token | Value |
|---|---|
| Primary Red | `#D92B2B` |
| Gold | `#F0A500` |
| Green | `#1A7A3C` |
| Background | `#0A0A0A` |
| Surface | `#111111` |
| Text | `#F0EDE4` |
| Display Font | Bebas Neue |
| Mono Font | Space Mono |
| Body Font | DM Sans |

---

**Africa Builds Different. 🌍**  
*VIBR · vibr.africa · All rights reserved.*
